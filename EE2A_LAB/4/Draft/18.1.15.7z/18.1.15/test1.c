#include<18F27K40.h>
#use delay(internal=32Mhz,clock_out) //set main frequency at 32MHz
#use RS232(baud=9600,xmit=PIN_C0,rcv=PIN_C1)
#int_timer2
void Timer2_Service_Routine(void)
{
   if (input(PIN_B0)==1)
   {
   printf("HiThere");
   }
   if (input(PIN_B0)==0) 
   {
   printf("ByeBye");
   }
}  
  
void main()
{
   int BWPU;//weak pull up PIN_B
   #byte BWPU = 0x0F18;
   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_128,249,1);
   enable_interrupts(GLOBAL);
   enable_interrupts(INT_TIMER2);
   while(1)
   {
   }

}

