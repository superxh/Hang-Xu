#include<18F27K40.h>
#use delay(internal=32Mhz,clock_out) //set main frequency at 32MHz
#use RS232(baud=9600,xmit=PIN_C0,rcv=PIN_C1)

#pin_select PWM4=PIN_A0 //select PIN_A0 as output of PWM


struct IO_Port_Definition
{
   int1 PWM;//PIN_A0
   int unusedA:7;//PIN_A1..7
   int SignalSelect:2;//PIN_B0..1
   int unusedB:6;//PIN_B2..7
   int1 xmit;//PIN_C0
   int1 debug;//PIN_C1
   int1 cs; //PIN_C2
   int1 SDO;//PIN_C3
   int1 unusedC2;//PIN_C4
   int1 SCK;//PIN_C5
   int1 unusedC3:2;//PIN_C6/PIN_C7
};
struct IO_Port_Definition Port;
struct IO_Port_Definition PortDirection;
#byte Port = 0xF8D
#byte PortDirection = 0xF88

#int_timer2
void Timer2_Service_Routine(void)
{
   Port.debug = 0b1;
   Port.cs = 0b0;//SPI Chip select signal low
   printf("HiThere");
   Port.cs = 0b1;//SPI Chip select signal high
   Port.debug = 0b0;
  }  

void main()
{
   int BWPU;//weak pull up PIN_B
   #byte BWPU = 0x0F18;
   BWPU = 0b11111111;
   PortDirection.cs = 0b0;//output
   PortDirection.PWM = 0b0;
   PortDirection.unusedA = 0b0000000;
   PortDirection.SignalSelect = 0b11;//input
   PortDirection.unusedB = 0b000000;
   PortDirection.xmit=0b0;
   PortDirection.debug=0b0;
   PortDirection.cs = 0b0;
   PortDirection.SDO=0b0;
   PortDirection.unusedC2=0b0;
   PortDirection.SCK=0b0;
   PortDirection.unusedC3=0b00;

   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_128,249,1);//32kHz
   setup_ccp2(CCP_PWM|CCP_USE_TIMER1_AND_TIMER2); // Configure CCP2 as a PWM,CCP2 is paired with Timer 2

   setup_pwm4(PWM_ENABLED|PWM_ACTIVE_LOW|PWM_TIMER2);
   set_pwm4_duty(32);//active low for 1us

   enable_interrupts(INT_TIMER2);// Timer 2 interrupt enable
   enable_interrupts(GLOBAL);// 'Global' interrupt enable
   while(1)
   {
   }

}
