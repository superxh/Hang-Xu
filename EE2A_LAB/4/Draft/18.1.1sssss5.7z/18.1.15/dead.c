#include <18F27K40.h> 
#include <stdio.h> 
#include <string.h>
#use delay(clock=4000000)
#use RS232(baud=9600,xmit=PIN_C0,rcv=PIN_C1,ERRORS)

#INT_RDA 
void rda_isr(void) 
{ 
   char c; 
   if(kbhit())
   {
   c = getc(); // Get character from PC 
   putc(c);    // Send it back to the PC
   }
    
}

void main() 
{ 
   enable_interrupts(INT_RDA); 
   enable_interrupts(GLOBAL); 
   while(1)
   {
   }
}
