#include <18F27K40.h> 
#include <stdio.h> 
#include <string.h>
#use delay(internal=32Mhz,clock_out) //set main frequency at 4MHz 

/***************rs232 setting***************/
#pin_select U1TX=PIN_C0
#pin_select U1RX=PIN_C1 
#use rs232(uart1, baud=9600, ERRORS)

/***************structure***************/
struct IO_Port_Definition
   {
   int unusedA:8;//PIN_A0..7 
   int unusedB:8;//PIN_B0..7 
   int1 ts;//PIN_C0 
   int1 rc;//PIN_C1 
   int1 debug; //PIN_C2 
   int unusedC:5; //PIN_C4..7 
   };
struct IO_Port_Definition Port; 
struct IO_Port_Definition PortDirection; 
#byte Port = 0xF8D 
#byte PortDirection = 0xF88 

/***************variable***************/
char c;
int in=0;
/***************RDA_interrupt***************/
#INT_RDA
void rda_isr(void) 
{ 
   Port.debug=0b1;
   output_low(PIN_C3);
   delay_ms(500);
   //c[0]=getc();
   //putc(c[0]);
   //c[1]=getc();
   //putc(c[1]);
   //c[2]=getc();
   //putc(c[2]);
   //puts(c);
   c=getc();
   Port.debug=0b0;
   
}

/***************main_function***************/
void main() 
{ 
   PortDirection.ts=0b0;
   PortDirection.rc=0b1;
   PortDirection.debug=0b0;
   enable_interrupts(INT_RDA); 
   enable_interrupts(GLOBAL); 
   //output_high(PIN_C3);
   while(1)
   {
   
/*******************************/
   output_high(PIN_C3);
   if (c==13)
      {
      output_high(PIN_C4);
      //putc(c); // Send it back to the PC
      
      }
      
/*******************************/
   }
}
