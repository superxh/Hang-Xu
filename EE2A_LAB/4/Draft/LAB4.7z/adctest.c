#include <18F27K40.h> 
#device adc=10
#use delay(internal=32Mhz,clock_out) //set main frequency at 32MHz 

/***************rs232 setting***************/
#pin_select U1TX=PIN_C0
#pin_select U1RX=PIN_C1 
#use rs232(uart1, baud=9600, ERRORS)


void main() 
{ 
int16 result; 

//setup_vref(VREF_ON | VREF_ADC_4v096);
//setup_adc_ports(sAN7 | VSS_FVR); 
setup_adc_ports(sAN7);
setup_adc(ADC_CLOCK_INTERNAL); 
set_adc_channel(7);

delay_us(20); 

while(1) 
  { 
   result = read_adc(); 
   printf("%lu \n\r", result); 
   delay_ms(500);  
  } 

}



