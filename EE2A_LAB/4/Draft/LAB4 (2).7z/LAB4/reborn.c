#include <18F27K40.h> 
#include <stdio.h> 
#include <string.h>
#use delay(internal=32Mhz,clock_out) //set main frequency at 4MHz 

/*******************************/
#pin_select U1TX=PIN_C0
#pin_select U1RX=PIN_C1 
#use rs232(uart1, baud=9600, ERRORS)

/*******************************/
struct IO_Port_Definition
   {
   int unusedA:8;//PIN_A0..7 
   int unusedB:8;//PIN_B0..7 
   int1 ts;//PIN_C0 
   int1 rc;//PIN_C1 
   int1 debug; //PIN_C2 
   int unusedC:5; //PIN_C4..7 
   };
struct IO_Port_Definition Port; 
struct IO_Port_Definition PortDirection; 
#byte Port = 0xF8D 
#byte PortDirection = 0xF88 

/*******************************/
char c; 
int only;

/*******************************/
#INT_RDA 
void rda_isr(void) 
{ 
   
   
   Port.debug=0b1;
   if (kbhit())
   {
   c=getc(); // Get character from PC 
   only=1;
   }
   Port.debug=0b0;
}

/*******************************/
void main() 
{ 
   PortDirection.ts=0b0;
   PortDirection.rc=0b1;
   PortDirection.debug=0b0;
   enable_interrupts(INT_RDA); 
   enable_interrupts(GLOBAL); 

   while(1)
   {
/*******************************/
   if (only==1)
      {
      putc(c); // Send it back to the PC
      only=0;
      }
/*******************************/
   }
}
