#include<18F27K40.h>
//#fuses HS, NOWDT, BROWNOUT, PUT, NOLVP 
#use delay(clock=4000000) 
#use rs232(baud=9600, xmit=PIN_C1, rcv=PIN_C0, ERRORS) 

#INT_RDA
void rda_isr(void) 
{ 
char c; 

c = getc();   // Get character from PC 

putc(c);    // Send it back to the PC 
}    

//======================== 
void main() 
{ 
enable_interrupts(INT_RDA); 
enable_interrupts(GLOBAL); 

while(1); 
}
