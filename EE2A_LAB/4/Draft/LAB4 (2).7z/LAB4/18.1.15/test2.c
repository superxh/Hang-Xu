#include <18F27K40.h> 
#fuses HS, NOWDT, PUT, BROWNOUT, NOLVP, MCLR  
#use delay(clock=4000000) 
#use RS232(baud=9600,xmit=PIN_C0,UART,rcv=PIN_C1,ERRORS) 
/*
#define SERIALBUFFSIZE 32
short int SerialCmdWaitFlg = FALSE; 
char      Serial_buffer[SERIALBUFFSIZE];
int       Serial_next_in = 0; 
int       Serial_next_out = 0;

void GetCom(char*command_string)
{
   int length; 
   char c; 

   length=0; 
   SerialCmdWaitFlg = FALSE; 
   do
   {
      c=Serial_buffer[Serial_next_out]; /* Get a character from the Serial buffer */
      /* 
      Serial_next_out=(Serial_next_out+1) % SERIALBUFFSIZE; 
   }
   while(c ==' '); /* A non-space character has been entered */ 
   /* 
   command_string[length++]=c; /* Get rest of command string - until space or CR terminated or input string is too long*/
   /* 
   while((c != ' ')&&(c != 13)&&(length<20)) 
   {
       c=Serial_buffer[Serial_next_out];  /* Get a character from the Serial buffer */ 
       /* 
       Serial_next_out=(Serial_next_out+1) % SERIALBUFFSIZE;
       command_string[length++]=c; 
   }
   command_string[--length] = 0;  /* Null terminate string */ 
   /* 
}
*/

#INT_RDA 
void rda_isr(void) 
{ 
   char c; 
   c = getc(); // Get character from PC 
   putc(c);    // Send it back to the PC 
}

void main() 
{ 
   enable_interrupts(INT_RDA); 
   enable_interrupts(GLOBAL); 
   //char CmdStr[15];  /* Input character string from Serial interface */ 
   while(1)
   {
   //enable_interrupts(INT_RDA); 
   //enable_interrupts(GLOBAL); 
   //char c; 
   //c = getc(); // Get character from PC 
   //putc(c);    // Send it back to the PC
   //Serial_buff
   er[Serial_next_in] = getc();
   //GetCom(CmdStr);
   //Serial_next_in = (Serial_next_in+1) % SERIALBUFFSIZE; 
   //printf(c);    // Send it back to the PC 
   //putc(13); // Go to first column
   //putc(10);  
   }
}
