#include <18F27K40.h> 
#device adc=10
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>

/***************main frequency setting***************/
#use delay(internal=32Mhz,clock_out) 

/***************rs232 setting***************/
#pin_select U1TX=PIN_C0
#pin_select U1RX=PIN_C1 
#use rs232(uart1, baud=9600, ERRORS)

/***************structure***************/
struct IO_Port_Definition
   {
   int unusedA:7;//PIN_A0..6 
   int1 ADC;//PIN_A7 
   int unusedB:8;//PIN_B0..7 
   int1 ts;//PIN_C0 
   int1 rc;//PIN_C1 
   int1 debug; //PIN_C2 
   int1 PWM; //PIN_C3 
   int1 LED4; //PIN_C4
   int unusedC:3; //PIN_C5..7 
   };
struct IO_Port_Definition Port; 
struct IO_Port_Definition PortDirection; 
#byte Port = 0xF8D 
#byte PortDirection = 0xF88 

/***************variable***************/
//RDA//
char c[32];
int  in=0;
//Sentence//

char     collectdata[]="COLLECT DATA";
char     putsdata[]="PUTS DATA";
//ADC//
float    adcresult;
int16    adctable[1024];
long     count=0;
int      adcswitch=2;
long     ii;
//Main//
int      pause=1;//1 for continue;0 for stop
int      flag=0;

/***************RDA_interrupt***************/
#INT_RDA
void rda_isr(void) 
{ 
   Port.debug=0b1;
   pause=1;
   adcswitch=2;
   c[0]=0;//reset c
   in=0;
   do
   {
   c[in]=getc();
   //putc(c[in]);
   if(c[in]==127)//backspace check
   {
   in=in-2;
   }
   in=in+1;
   }
   while((in<31)&&(c[in-1]!=13));
   c[in-1]=0;
   //putc(13);
   //putc(10);
   //printf(c)//Command Collected 
   Port.debug=0b0;
   //ERROR JUDGEMENT//
   if(STRICMP(c,collectdata)!=0)
   {
   //puts("ERROR");
   }
   if(count==1024&&STRICMP(c,putsdata)==0)
   {   
   float adcvalue = (adctable[ii]*4.096)/1023;
   printf("%f ",adcvalue);
   ii=ii+1;
   putc(13);
   putc(10);
   }
}

/***************ADC_interrupt***************/
#INT_AD
void adc_isr(void)
{  
   if(adcswitch==0)
   {
      if(count<1024)
      {
      adcresult = read_adc(ADC_READ_ONLY); 
      adctable[count++] = adcresult;
      }
   }
}

/***************main_function***************/
void main() 
{ 
   //Port Setting//
   PortDirection.ADC=0b1;
   PortDirection.ts=0b0;
   PortDirection.rc=0b1;
   PortDirection.debug=0b0;
   PortDirection.PWM = 0b0;
   PortDirection.LED4 = 0b0;
   //RDA//
   enable_interrupts(INT_RDA); 
   //ADC//
   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_1,249,1);
   setup_adc_ports(sAN7,VSS_FVR);
   setup_adc(ADC_LEGACY_MODE|ADC_CLOCK_DIV_64);
   setup_vref(VREF_ON|VREF_ADC_4v096);
   set_adc_channel(7);
   set_adc_trigger(ADC_TRIGGER_TIMER2);
   enable_interrupts(INT_AD);
   //GLOBAL//
   enable_interrupts(GLOBAL); 
   while(1)
   {
   flag=0;//ERROR JUDGEFLAG,0 for ERROR;1 for OK
/**************ADC CONTROL*****************/ 
    if (STRICMP(c,collectdata)==0)
      {
      puts("OK");
      flag=1;
      pause=0;
      count=0;
      adcswitch=0;
      while(pause==0)
      {
      

               while(pause==0);
            }
           
      }
      }
      if (flag==0)
          {
            pause=0;
            while(pause==0);
          }
   }
 
