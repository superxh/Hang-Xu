#ifndef SW2
#define SW2 1
 
#banky
signed int16 sine_window[4] = {
23170,
23170
};

#endif
