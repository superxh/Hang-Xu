Fs = 32000;            % Sampling frequency                    
T = 1/Fs;             % Sampling period       
L = 1024;             % Length of signal
t = (0:L-1)*T;        % Time vector

S = cos(2*pi*1000*t) + cos(2*pi*2000*t);
X = S ;%+ 2*randn(size(t));

Local1_real=cos(2*pi*1000*t);
Local1_imag=-sin(2*pi*1000*t);
Local2_real=cos(2*pi*2000*t);
Local2_imag=-sin(2*pi*2000*t);

plot(t,X)
title('Signal Corrupted with Zero-Mean Random Noise')
xlabel('t (milliseconds)')
ylabel('X(t)')

Multi_1coscos=Local1_real.*X;
Multi_1cossin=Local1_imag.*X;
Multi_2coscos=Local2_real.*X;
Multi_2cossin=Local2_imag.*X;
Filter_Multi_1coscos=0;
Filter_Multi_1cossin=0;
Filter_Multi_2coscos=0;
Filter_Multi_2cossin=0;
%{
for a=1:1:896
    Filter_Multi_1coscos= Filter_Multi_1coscos+(sum(Multi_1coscos(a:a+127)))/128;
    Filter_Multi_1cossin= Filter_Multi_1cossin+(sum(Multi_1cossin(a:a+127)))/128;
    Filter_Multi_2coscos= Filter_Multi_2coscos+(sum(Multi_2coscos(a:a+127)))/128;
    Filter_Multi_2cossin= Filter_Multi_2cossin+(sum(Multi_2cossin(a:a+127)))/128;
end

Filter_Multi_1coscos=Filter_Multi_1coscos/448;
Filter_Multi_1cossin=Filter_Multi_1cossin/448;
Filter_Multi_2coscos=Filter_Multi_2coscos/448;
Filter_Multi_2cossin=Filter_Multi_2cossin/448;
%}


    Filter_Multi_1coscos= (sum(Multi_1coscos(1:1024)))/1;
    Filter_Multi_1cossin= (sum(Multi_1cossin(1:1024)))/1;
    Filter_Multi_2coscos= (sum(Multi_2coscos(1:1024)))/1;
    Filter_Multi_2cossin= (sum(Multi_2cossin(1:1024)))/1;
    %fourkreal(a) = (Filter_Multi_1coscos(a)^(2)-Filter_Multi_1cossin(a)^(2))*Filter_Multi_2coscos(a)+2*Filter_Multi_1coscos(a)*Filter_Multi_1cossin(a)*Filter_Multi_2cossin(a);
    %fourkimag(a) = (Filter_Multi_1coscos(a)^(2)-Filter_Multi_1cossin(a)^(2))*Filter_Multi_2cossin(a)+2*Filter_Multi_1coscos(a)*Filter_Multi_1cossin(a)*Filter_Multi_2coscos(a);
    



%{
figure(1);
plot(Filter_Multi_1coscos);
figure(2);
plot(Filter_Multi_1cossin);
figure(3);
plot(Filter_Multi_2coscos);
figure(4);
plot(Filter_Multi_2cossin);
    %}
%{
figure(5);
plot(fourkreal);
figure(6);
plot(fourkimag);
%}
Filter_Multi_1coscos(1);
Filter_Multi_1cossin(1);
Filter_Multi_2coscos(1);
Filter_Multi_2cossin(1);