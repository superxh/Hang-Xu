Fs = 1000;            % Sampling frequency                    
T = 1/Fs;             % Sampling period       
L = 1500;             % Length of signal
t = (0:L-1)*T;        % Time vector

S = sin(2*pi*50*(t)+pi/3) + sin(2*pi*100*t);
X = S; % + 2*randn(size(t));

plot(1000*t(1:50),X(1:50))
title('Signal Corrupted with Zero-Mean Random Noise')
xlabel('t (milliseconds)')
ylabel('X(t)')

Y = fft(X);

Yphase = Y/L;
P4 = Yphase(1:L/2+1);
P4(2:end-1) = 2*P4(2:end-1);

P2 = real(Y/L);
P3 = imag(Y/L);
P1 = P2(1:L/2+1);
P11 = P3(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
P11(2:end-1) = 2*P11(2:end-1);

f = Fs*(0:(L/2))/L;
figure(1);
plot(f,P1,f,P11) 
title('Single-Sided Amplitude Spectrum of X(t)')
xlabel('f (Hz)')
ylabel('|P1(f)|')
figure(2);
plot(f,angle(P4)*180/pi);


