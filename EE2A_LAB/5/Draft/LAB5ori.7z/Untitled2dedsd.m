clear;
t = 0:1:128;
q = sin(t)*cos((pi/2)*t);
plot(t,q);