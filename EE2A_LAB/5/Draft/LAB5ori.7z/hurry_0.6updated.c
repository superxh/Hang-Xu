#include <18F27K40.h> 
#device adc=8
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>

/***************main frequency setting***************/
#use delay(internal=64Mhz,clock_out) 

/***************rs232 setting***************/
#pin_select U1TX=PIN_C0 // transmit data
#pin_select U1RX=PIN_C1 // receive data
#use rs232(uart1, baud=9600, ERRORS)

/***************spi setting***************/
#use spi(MASTER,DO=PIN_A2,MODE=0,CLK=PIN_A3,BITS=8) //set SPI

/***************pwm setting***************/
#pin_select PWM4=PIN_A0 //select PIN_A0 as output of PWM

/***************structure***************/
struct IO_Port_Definition
   {
   int1 PWM;//PIN_A0(LDAC)
   int1 cs; //PIN_A1
   int1 SDO;//PIN_A2
   int1 SCK; //PIN_A3
   int unusedA:3;//PIN_A4..6
   int1 ADC;//PIN_A7 
   int SignalSelect:2;//PIN_B0..1
   int unusedB:6;//PIN_B2..7 
   int1 ts;//PIN_C0 
   int1 rc;//PIN_C1 
   int unusedC:6; //PIN_C2..7 
   };
struct IO_Port_Definition Port; 
struct IO_Port_Definition PortDirection; 
#byte Port = 0xF8D 
#byte PortDirection = 0xF88 

/***************variables***************/
//RDA//
char c[32];
int  in=0;

//Sentence//
char     collectdata[]="COLLECT DATA";

//ADC//
int16    adctable[128];
long     count=0;

//Main//
int      pause=1;//1 for continue;0 for stop

//Look up table//
int16 CosTable[32]={1024,1000,930,823,693,556,429,325,256,226,233,272,331,397,457,497,512,497,457,397,331,272,233,226,256,325,429,556,693,823,930,1000};//LUT for combined 1 kHz + 2 kHz signal

int Look_Up_Table_Index=0;

int i;

/***************RDA_interrupt***************/
#INT_RDA
void rda_isr(void) 
{ 
   pause=1;
   c[0]=0;//reset c
   in=0;
   do
   {
      c[in]=getc();
      putc(c[in]);
      if(c[in]==127)//backspace check
      {
         in=in-2;
      }
      in=in+1;
   }
   while((in<31)&&(c[in-1]!=13));
   c[in-1]=0;
   putc(13);//enter
   putc(10);//back to first column

   //ERROR JUDGEMENT//
   if(STRICMP(c,collectdata)!=0)
   {
      puts("ERROR");
   }
}

/***************Timer2_interrupt***************/
#int_timer2
void Timer2_Service_Routine(void)
{
   Port.cs = 0b0;//SPI Chip select signal low
   spi_xfer((CosTable[Look_Up_Table_Index])>>8); //High byte(+4096(2^12) for SHDN=1)
   spi_xfer((CosTable[Look_Up_Table_Index])&0x00FF);// Low byte
   Port.cs = 0b1;//SPI Chip select signal high
   Look_Up_Table_Index=++Look_Up_Table_Index % 32;//if already count to 32, then reset to 0
   //read_adc();
}

/***************ADC_interrupt***************/
#INT_AD
void adc_isr(void)
{  
   if(count<128)
   {
      adctable[count++] = read_adc(ADC_READ_ONLY); 
   }
}

/***************main_function***************/
void main() 
{ 
   //Port Setting//
   int BWPU;//weak pull up PIN_B
   #byte BWPU = 0x0F18;
   BWPU = 0b11111111;
      //A//
   PortDirection.PWM=0b0;
   PortDirection.ADC=0b1;
      //B//
   PortDirection.SignalSelect=0b11;//input
      //C//
   PortDirection.ts=0b0;
   PortDirection.rc=0b1;
   PortDirection.cs=0b0;
   PortDirection.SDO=0b0;
   PortDirection.SCK=0b0;

   //RDA//
   enable_interrupts(INT_RDA); 
   //TIMER2//
   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_2,249,1);
   enable_interrupts(INT_TIMER2);// Timer 2 interrupt enable
   //PWM//
   setup_ccp2(CCP_PWM|CCP_USE_TIMER1_AND_TIMER2); 
   setup_pwm4(PWM_ENABLED|PWM_ACTIVE_LOW|PWM_TIMER2);
   set_pwm4_duty(64);//active low for 1us
   //ADC//
   setup_adc_ports(sAN7,VSS_FVR);
   setup_adc(ADC_LEGACY_MODE|ADC_CLOCK_DIV_64);
   setup_vref(VREF_ON|VREF_ADC_1v024);
   set_adc_channel(7);
   set_adc_trigger(ADC_TRIGGER_TIMER2);
   enable_interrupts(INT_AD);
   //GLOBAL//
   enable_interrupts(GLOBAL); 
   
   for(i=0;i<32;i++)
   {
   CosTable[i]=CosTable[i]+4096;
   }
   
   while(1)
   {
/**************ADC CONTROL*****************/ 
      if (STRICMP(c,collectdata)==0)
      {
         puts("OK");
         pause=0;
         count=0;
         while(pause==0)
         {
            if(count==128)
            {  
               long ii;
               printf("[");
               for(ii=0;ii<128;ii++)
               {
                  //float adcvalue = (adctable[ii]);//*4.096/1023;
                  if(ii<128)
                  {
                     //printf("%f ",adcvalue);
                     printf("%ld ",adctable[ii]);
                  }
               }
               printf("];");
               putc(13);
               putc(10);
               pause=1;
            }    
        }
      c[0]=0;//reset c
      }
   }
}
