Fs = 32000;            % Sampling frequency                    
T = 1/Fs;             % Sampling period       
L = 1024;             % Length of signal
t = (0:L-1)*T;        % Time vector

S = sin(2*pi*1000*t) + sin(2*pi*2000*t);
X = S + 2*randn(size(t));

Local1_real=cos(2*pi*1000*t);
Local1_imag=-sin(2*pi*1000*t);
Local2_real=cos(2*pi*2000*t);
Local2_imag=-sin(2*pi*2000*t);

plot(t,X)
title('Signal Corrupted with Zero-Mean Random Noise')
xlabel('t (milliseconds)')
ylabel('X(t)')

Multi_1coscos=Local1_real.*X;
Multi_1cossin=Local1_imag.*X;
Multi_2coscos=Local2_real.*X;
Multi_2cossin=Local2_imag.*X;
Filter_Multi_1coscos=0;
Filter_Multi_1cossin=0;
Filter_Multi_2coscos=0;
Filter_Multi_2cossin=0;
for a=1:1:896
    Filter_Multi_1coscos= Filter_Multi_1coscos+(sum(Multi_1coscos(a:a+127)))/128;
    Filter_Multi_1cossin= Filter_Multi_1cossin+(sum(Multi_1cossin(a:a+127)))/128;
    Filter_Multi_2coscos= Filter_Multi_2coscos+(sum(Multi_2coscos(a:a+127)))/128;
    Filter_Multi_2cossin= Filter_Multi_2cossin+(sum(Multi_2cossin(a:a+127)))/128;
end
Filter_Multi_1coscos=Filter_Multi_1coscos/448;
Filter_Multi_1cossin=Filter_Multi_1cossin/448;
Filter_Multi_2coscos=Filter_Multi_2coscos/448;
Filter_Multi_2cossin=Filter_Multi_2cossin/448;

Filter_Multi_1coscos;
Filter_Multi_1cossin;
Filter_Multi_2coscos;
Filter_Multi_2cossin;

%{
Y = fft(X);

Yphase = Y/L;
P4 = Yphase(1:L/2+1);
P4(2:end-1) = 2*P4(2:end-1);

P2 = real(Y/L);
P3 = imag(Y/L);
P1 = P2(1:L/2+1);
P11 = P3(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
P11(2:end-1) = 2*P11(2:end-1);

f = Fs*(0:(L/2))/L;
figure(1);
plot(f,P1,f,P11) 
title('Single-Sided Amplitude Spectrum of X(t)')
xlabel('f (Hz)')
ylabel('|P1(f)|')
figure(2);
plot(f,angle(P4)*180/pi);
%}

