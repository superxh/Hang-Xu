SamplingFrequency = 32e3;
DataBlockSize = 2^10;
TX_Frequency_1 = 1000;
TX_Frequency_2 = 2000;
DisplayTime = (0:(DataBlockSize-1))/SamplingFrequency;
TransmissionSignal = sin(2*pi*TX_Frequency_1*DisplayTime) + sin(2*pi*TX_Frequency_2*DisplayTime);
Local1=cos(2*pi*TX_Frequency_1*DisplayTime)-1j*sin(2*pi*TX_Frequency_1*DisplayTime);
Multi_1=TransmissionSignal.*Local1;
for a=1:1:896
    Filter_Multi_1(a)= imag(sum(Multi_1(a:a+127))/128);
end

Figure1Handle = figure(1); 
Figure1Handle.Color = 'w'; 
plot(DisplayTime,TransmissionSignal,'k','linewidth',1.5); 
set(gca,'Fontsize',11,'linewidth',1.5); 
xlabel('Time (S)','FontSize',11,'FontWeight','demi') 
ylabel('Voltage (V)','FontSize',11,'FontWeight','demi') 
title('Transmission Signal','FontSize',11,'FontWeight','demi'); 
figure(2);
plot(1:1:896,Filter_Multi_1); 
% sinwt
%si=sinwt*coswt=0.5sin2wt
%sq=sinwt*-sinwt=0.5cos2wt-0.5
%s=sicoswt-sqsinwt
