samplingfrequency=32e3;
datablocksize=2^10;
tx_frequency_1=1000;
tx_frequency_2=2000;
tx_socal_fre=2000;
displaytime=(0:(datablocksize-1))/samplingfrequency;


%randomtimeoffset=rand;
%randomtimeoffset=rand;
%randomtimeoffset1=randomtimeoffset;
transimmisionsignal=cos(2*pi*tx_frequency_1*(displaytime))+cos(2*pi*tx_frequency_2*(displaytime));
%transimmisionsignal=-transimmisionsignal;
%oscal1=cos(2*pi*tx_frequency_1*(displaytime));
%oscal2=-1j*sin(2*pi*tx_frequency_1*(displaytime));
oscal = exp(-1j*2*pi*tx_socal_fre*(displaytime));
%oscal = -oscal;
output1=real(oscal.*transimmisionsignal);
output2=imag(oscal.*transimmisionsignal);
%fun=@(t)exp(-1*j*1000*t)*
a=1;
while a < 896
    filter1(a)=sum(output1(a:a+127));
    filter2(a)=sum(output2(a:a+127));
    a=a+1;
end
filter1=filter1/128;
filter2=filter2/128;

axisholder=[1:1:896];

plot(axisholder,filter1,'y',axisholder,filter2,'b');
figure1handle=figure(1);
figure1handle.Color='w';
set(gca,'FontSize',11,'linewidth',1.5);
xlabel('Time(S)','FontSize',11,'FontWeight','demi')
ylabel('Voltage(V)','FontSize',11,'FontWeight','demi')
title('Transmission signal','FontSize',11,'FontWeight','demi');
    %xlim([0,0.005])
    %ylim([-2,1.5])
    pause(1)