#include <18F27K40.h> 
#device adc=8
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>

/***************main frequency setting***************/
#use delay(internal=64Mhz,clock_out) 

/***************rs232 setting***************/
#pin_select U1TX=PIN_C0 // transmit data
#pin_select U1RX=PIN_C1 // receive data
#use rs232(uart1, baud=9600, ERRORS)

/***************spi setting***************/
#use spi(MASTER,DO=PIN_A2,MODE=0,CLK=PIN_A3,BITS=8) //set SPI

/***************pwm setting***************/
#pin_select PWM4=PIN_A0 //select PIN_A0 as output of PWM

/***************structure***************/
struct IO_Port_Definition
   {
   int1 PWM;//PIN_A0(LDAC)
   int1 cs; //PIN_A1
   int1 SDO;//PIN_A2
   int1 SCK; //PIN_A3
   int unusedA:3;//PIN_A4..6
   int1 ADC;//PIN_A7 
   int SignalSelect:2;//PIN_B0..1
   int unusedB:6;//PIN_B2..7 
   int1 ts;//PIN_C0 
   int1 rc;//PIN_C1 
   int unusedC:6; //PIN_C2..7 
   };
struct IO_Port_Definition Port; 
struct IO_Port_Definition PortDirection; 
#byte Port = 0xF8D 
#byte PortDirection = 0xF88 

/***************variables***************/
//RDA//
char c[32];
int  in=0;

//Sentence//
char     collectdata[]="COLLECT DATA";

//ADC//
signed int16    adctable[128];
long     count=0;

//Main//
int      pause=1;//1 for continue;0 for stop

//Look up table//
int16 SineTab1e[32]={2048   ,2639   ,3163   ,3562   ,3795   ,3845   ,3717   ,3443   ,3071   ,2660   ,2269   ,1953   ,1748   ,1670   ,1715   
   ,1855   ,2048   ,2240   ,2380   ,2425   ,2347   ,2142   ,1826   ,1435   ,1024   ,652   ,378   ,250   ,300   ,533   ,932   ,1456  };//LUT for combined 1 kHz + 2 kHz signal

unsigned int8 Local1_real[32]={127,125,117,106,90,71,49,25,0,-25,-49,-71,-90,-106,-117,-125,-127,-125,-117,-106,-90,-71,-49,-25,0,25,49,71,90,106,117,125};
unsigned int8 Local1_imag[32]={0,-25,-49,-71,-90,-106,-117,-125,-127,-125,-117,-106,-90,-71,-49,-25,0,25,49,71,90,106,117,125,127,125,117,106,90,71,49,25};
unsigned int8 Local2_real[32]={127,117,90,49,0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117,127,117,90,49,0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117};
unsigned int8 Local2_imag[32]={0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117,127,117,90,49,0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117,127,117,90,49};

signed int16 Multi_1coscos[128];
signed int16 Multi_1cossin[128];
signed int16 Multi_2coscos[128];
signed int16 Multi_2cossin[128];

signed int16 Filter_Multi_1coscos[96];
signed int16 Filter_Multi_1cossin[96];
signed int16 Filter_Multi_2coscos[96];
signed int16 Filter_Multi_2cossin[96];

signed int16 FourkReal[96];
//unsigned int16 FourkImag[96];

int Look_Up_Table_Index=0;
int i;

/***************RDA_interrupt***************/
#INT_RDA
void rda_isr(void) 
{ 
   pause=1;
   c[0]=0;//reset c
   in=0;
   do
   {
      c[in]=getc();
      putc(c[in]);
      if(c[in]==127)//backspace check
      {
         in=in-2;
      }
      in=in+1;
   }
   while((in<31)&&(c[in-1]!=13));
   c[in-1]=0;
   putc(13);//enter
   putc(10);//back to first column

   //ERROR JUDGEMENT//
   if(STRICMP(c,collectdata)!=0)
   {
      puts("ERROR");
   }
}

/***************Timer2_interrupt***************/
#int_timer2
void Timer2_Service_Routine(void)
{
   Port.cs = 0b0;//SPI Chip select signal low
   spi_xfer((SineTab1e[Look_Up_Table_Index])>>8); //High byte(+4096(2^12) for SHDN=1)
   spi_xfer((SineTab1e[Look_Up_Table_Index])&0x00FF);// Low byte
   Port.cs = 0b1;//SPI Chip select signal high
   Look_Up_Table_Index=++Look_Up_Table_Index % 32;//if already count to 32, then reset to 0
   //read_adc();
}

/***************ADC_interrupt***************/
#INT_AD
void adc_isr(void)
{  
   if(count<128)
   {
      adctable[count] = read_adc(ADC_READ_ONLY);
      adctable[count]-=51;

      count++;
   }
}

/***************main_function***************/
void main() 
{ 
   //Port Setting//
   int BWPU;//weak pull up PIN_B
   #byte BWPU = 0x0F18;
   BWPU = 0b11111111;
      //A//
   PortDirection.PWM=0b0;
   PortDirection.ADC=0b1;
      //B//
   PortDirection.SignalSelect=0b11;//input
      //C//
   PortDirection.ts=0b0;
   PortDirection.rc=0b1;
   PortDirection.cs=0b0;
   PortDirection.SDO=0b0;
   PortDirection.SCK=0b0;

   //RDA//
   enable_interrupts(INT_RDA); 
   //TIMER2//
   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_2,249,1);
   enable_interrupts(INT_TIMER2);// Timer 2 interrupt enable
   //PWM//
   setup_ccp2(CCP_PWM|CCP_USE_TIMER1_AND_TIMER2); 
   setup_pwm4(PWM_ENABLED|PWM_ACTIVE_LOW|PWM_TIMER2);
   set_pwm4_duty(64);//active low for 1us
   //ADC//
   setup_adc_ports(sAN7,VSS_FVR);
   setup_adc(ADC_LEGACY_MODE|ADC_CLOCK_DIV_64);
   setup_vref(VREF_ON|VREF_ADC_4v096);
   set_adc_channel(7);
   set_adc_trigger(ADC_TRIGGER_TIMER2);
   enable_interrupts(INT_AD);
   //GLOBAL//
   enable_interrupts(GLOBAL); 
   
   for(i=0;i<32;i++)
   {
      SineTab1e[i]=SineTab1e[i]+4096;
   }
   
   while(1)
   {
/**************ADC CONTROL*****************/ 

      
      if (STRICMP(c,collectdata)==0)
      {
         puts("OK");
         pause=0;
         count=0;
         while(pause==0)
         {
            if(count==128)
            {  
            
               long ii;
               printf("[");
               for(ii=0;ii<128;ii++)
               {
                  //float adcvalue = (adctable[ii]);//*4.096/1023;
                  if(ii<128)
                  {
                     //printf("%f ",adcvalue);
                     printf("%ld ",adctable[ii]);
                  }
               }
               printf("];");
               putc(13);
               putc(10);
               int a;
               for (a=0;a<128;a++)
               {
                  Multi_1coscos[a] = adctable[a]*(signed int16)Local1_real[a%32];
                  Multi_1cossin[a] = adctable[a]*(signed int16)Local1_imag[a%32];
                  Multi_2coscos[a] = adctable[a]*(signed int16)Local2_real[a%32];
                  Multi_2cossin[a] = adctable[a]*(signed int16)Local2_imag[a%32];
               }
               for (a=0;a<128-32;a++)
               {
                   Filter_Multi_1coscos[a]= (Multi_1coscos[a]+Multi_1coscos[a+1]+Multi_1coscos[a+2]+Multi_1coscos[a+3]+Multi_1coscos[a+4]+Multi_1coscos[a+5]+Multi_1coscos[a+6]+Multi_1coscos[a+7]+Multi_1coscos[a+8]+Multi_1coscos[a+9]+Multi_1coscos[a+10]+Multi_1coscos[a+11]+Multi_1coscos[a+12]+Multi_1coscos[a+13]+Multi_1coscos[a+14]+Multi_1coscos[a+15]+Multi_1coscos[a+16]+Multi_1coscos[a+17]+Multi_1coscos[a+18]+Multi_1coscos[a+19]+Multi_1coscos[a+20]+Multi_1coscos[a+21]+Multi_1coscos[a+22]+Multi_1coscos[a+23]+Multi_1coscos[a+24]+Multi_1coscos[a+25]+Multi_1coscos[a+26]+Multi_1coscos[a+27]+Multi_1coscos[a+28]+Multi_1coscos[a+29]+Multi_1coscos[a+30]+Multi_1coscos[a+31])/16;
                   Filter_Multi_1cossin[a]= (Multi_1cossin[a]+Multi_1cossin[a+1]+Multi_1cossin[a+2]+Multi_1cossin[a+3]+Multi_1cossin[a+4]+Multi_1cossin[a+5]+Multi_1cossin[a+6]+Multi_1cossin[a+7]+Multi_1cossin[a+8]+Multi_1cossin[a+9]+Multi_1cossin[a+10]+Multi_1cossin[a+11]+Multi_1cossin[a+12]+Multi_1cossin[a+13]+Multi_1cossin[a+14]+Multi_1cossin[a+15]+Multi_1cossin[a+16]+Multi_1cossin[a+17]+Multi_1cossin[a+18]+Multi_1cossin[a+19]+Multi_1cossin[a+20]+Multi_1cossin[a+21]+Multi_1cossin[a+22]+Multi_1cossin[a+23]+Multi_1cossin[a+24]+Multi_1cossin[a+25]+Multi_1cossin[a+26]+Multi_1cossin[a+27]+Multi_1cossin[a+28]+Multi_1cossin[a+29]+Multi_1cossin[a+30]+Multi_1cossin[a+31])/16;
                   Filter_Multi_2coscos[a]= (Multi_2coscos[a]+Multi_2coscos[a+1]+Multi_2coscos[a+2]+Multi_2coscos[a+3]+Multi_2coscos[a+4]+Multi_2coscos[a+5]+Multi_2coscos[a+6]+Multi_2coscos[a+7]+Multi_2coscos[a+8]+Multi_2coscos[a+9]+Multi_2coscos[a+10]+Multi_2coscos[a+11]+Multi_2coscos[a+12]+Multi_2coscos[a+13]+Multi_2coscos[a+14]+Multi_2coscos[a+15]+Multi_2coscos[a+16]+Multi_2coscos[a+17]+Multi_2coscos[a+18]+Multi_2coscos[a+19]+Multi_2coscos[a+20]+Multi_2coscos[a+21]+Multi_2coscos[a+22]+Multi_2coscos[a+23]+Multi_2coscos[a+24]+Multi_2coscos[a+25]+Multi_2coscos[a+26]+Multi_2coscos[a+27]+Multi_2coscos[a+28]+Multi_2coscos[a+29]+Multi_2coscos[a+30]+Multi_2coscos[a+31])/16;
                   Filter_Multi_2cossin[a]= (Multi_2cossin[a]+Multi_2cossin[a+1]+Multi_2cossin[a+2]+Multi_2cossin[a+3]+Multi_2cossin[a+4]+Multi_2cossin[a+5]+Multi_2cossin[a+6]+Multi_2cossin[a+7]+Multi_2cossin[a+8]+Multi_2cossin[a+9]+Multi_2cossin[a+10]+Multi_2cossin[a+11]+Multi_2cossin[a+12]+Multi_2cossin[a+13]+Multi_2cossin[a+14]+Multi_2cossin[a+15]+Multi_2cossin[a+16]+Multi_2cossin[a+17]+Multi_2cossin[a+18]+Multi_2cossin[a+19]+Multi_2cossin[a+20]+Multi_2cossin[a+21]+Multi_2cossin[a+22]+Multi_2cossin[a+23]+Multi_2cossin[a+24]+Multi_2cossin[a+25]+Multi_2cossin[a+26]+Multi_2cossin[a+27]+Multi_2cossin[a+28]+Multi_2cossin[a+29]+Multi_2cossin[a+30]+Multi_2cossin[a+31])/16;
                   //FourkReal[a] = ((Filter_Multi_1coscos[a]^(2)-Filter_Multi_1cossin[a]^(2))*Filter_Multi_2coscos[a]+2*Filter_Multi_1coscos[a]*Filter_Multi_1cossin[a]*Filter_Multi_2cossin[a])/(2*10^16);
                   //FourkImag[a] = ((Filter_Multi_1coscos[a]^(2)-Filter_Multi_1cossin[a]^(2))*Filter_Multi_2cossin[a]+2*Filter_Multi_1coscos[a]*Filter_Multi_1cossin[a]*Filter_Multi_2coscos[a])/(2*10^16);
                   printf("%ld,  %ld,  %ld,  %ld\n\r",Filter_Multi_1coscos[a],Filter_Multi_1cossin[a],Filter_Multi_2coscos[a],Filter_Multi_2cossin[a]);
                    //printf("%ld,",Filter_Multi_1coscos[a]);
               }
               pause=1;
            }    
        }
      c[0]=0;//reset c
      }
   }
}
