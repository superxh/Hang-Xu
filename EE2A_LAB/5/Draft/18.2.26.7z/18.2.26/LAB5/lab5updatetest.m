clear

Fs = 32000;            % Sampling frequency                    
T = 1/Fs;             % Sampling period       
L = 128;             % Length of signal
t = (0:L-1)*T;        % Time vector

S = [-8 -3 2 6 7 5 0 -8 -18 -28 -38 -44 -48 -47 -41 -31 -18 -3 12 25 35 41 42 39 32 23 13 3 -5 -10 -12 -11 -7 -3 2 6 7 5 0 -8 -18 -28 -38 -44 -48 -47 -41 -31 -18 -3 12 25 35 41 42 39 32 23 13 3 -5 -10 -12 -11 -7 -3 2 6 7 5 0 -8 -18 -28 -38 -45 -48 -47 -41 -31 -18 -3 12 25 35 41 42 39 33 23 13 3 -5 -10 -12 -11 -7 -3 2 6 7 5 0 -8 -18 -28 -38 -45 -48 -47 -41 -31 -18 -3 12 25 35 41 42 39 32 23 13 3 -5 -10 -12 -11 ];

X = S ;%+ 2*randn(size(t));

Local1_real=round(cos(2*pi*1000*t)*127);
Local1_imag=round(-1*sin(2*pi*1000*t)*127);
Local2_real=round(cos(2*pi*2000*t)*127);
Local2_imag=round(-1*sin(2*pi*2000*t)*127);

plot(t,X)
title('Signal Corrupted with Zero-Mean Random Noise')
xlabel('t (milliseconds)')
ylabel('X(t)')

Multi_1coscos=Local1_real.*X;
Multi_1cossin=Local1_imag.*X;
Multi_2coscos=Local2_real.*X;
Multi_2cossin=Local2_imag.*X;
Filter_Multi_1coscos=0;
Filter_Multi_1cossin=0;
Filter_Multi_2coscos=0;
Filter_Multi_2cossin=0;

%for a=1:1:128-32
a=1
    Filter_Multi_1coscos(a)= 2*(sum(Multi_1coscos(a:a+127)))/32;
    Filter_Multi_1cossin(a)= 2*(sum(Multi_1cossin(a:a+127)))/32;
    Filter_Multi_2coscos(a)= 2*(sum(Multi_2coscos(a:a+127)))/32;
    Filter_Multi_2cossin(a)= 2*(sum(Multi_2cossin(a:a+127)))/32;
    fourkreal(a) = ((Filter_Multi_1coscos(a)^(2)-Filter_Multi_1cossin(a)^(2))*Filter_Multi_2coscos(a)+2*Filter_Multi_1coscos(a)*Filter_Multi_1cossin(a)*Filter_Multi_2cossin(a))/(2*10^16);
    fourkimag(a) = ((Filter_Multi_1coscos(a)^(2)-Filter_Multi_1cossin(a)^(2))*Filter_Multi_2cossin(a)+2*Filter_Multi_1coscos(a)*Filter_Multi_1cossin(a)*Filter_Multi_2coscos(a))/(2*10^16);
    
%end

figure(1);
plot(Filter_Multi_1coscos);
figure(2);
plot(Filter_Multi_1cossin);
figure(3);
plot(Filter_Multi_2coscos);
figure(4);
plot(Filter_Multi_2cossin);
figure(5);
plot(fourkreal);
figure(6);
plot(fourkimag);

Filter_Multi_1coscos(1);
Filter_Multi_1cossin(1);
Filter_Multi_2coscos(1);
Filter_Multi_2cossin(1);