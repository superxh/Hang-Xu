t = 0:1/(1000*32):1/1000;        % Time vector
S = round(1024*(2+(cos(2*pi*1000*t)+cos(2*pi*2000*t))));

figure(7);
plot(S);