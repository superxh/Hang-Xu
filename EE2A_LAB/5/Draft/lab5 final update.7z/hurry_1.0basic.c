#include <18F27K40.h> 
#device adc=8
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>

/***************main frequency setting***************/
#use delay(internal=64Mhz,clock_out) 

/***************rs232 setting***************/
#pin_select U1TX=PIN_C0 // transmit data
#pin_select U1RX=PIN_C1 // receive data
#use rs232(uart1, baud=9600, ERRORS)

/***************spi setting***************/
#use spi(MASTER,DO=PIN_A2,MODE=0,CLK=PIN_A3,BITS=8) //set SPI

/***************pwm setting***************/
#pin_select PWM4=PIN_A0 //select PIN_A0 as output of PWM

/***************structure***************/
struct IO_Port_Definition
   {
   int1 PWM;//PIN_A0(LDAC)
   int1 cs; //PIN_A1
   int1 SDO;//PIN_A2
   int1 SCK; //PIN_A3
   int unusedA:3;//PIN_A4..6
   int1 ADC;//PIN_A7 
   int unusedB:8;//PIN_B0..7 
   int1 ts;//PIN_C0 
   int1 rc;//PIN_C1 
   int unusedC:6; //PIN_C2..7 
   };
struct IO_Port_Definition Port; 
struct IO_Port_Definition PortDirection; 
#byte Port = 0xF8D 
#byte PortDirection = 0xF88 

/***************variables***************/
//RDA//
char c[32];
int  in=0;

//Sentence//
char     collectdata[]="COLLECT DATA";

//ADC//
int16    adctable[128];
long     count=0;

//Main//
int      pause=1;//1 for continue;0 for stop

//Look up table//
int16 CosTable[32]={1024,1000,930,823,693,556,429,325,256,226,233,272,331,397,457,497,512,497,457,397,331,272,233,226,256,325,429,556,693,823,930,1000};//LUT for combined 1 kHz + 2 kHz signal
signed int8 local1_real[128]={64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63};
signed int8 local1_imag[128]={0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12,0,-12,-24,-36,-45,-53,-59,-63,-64,-63,-59,-53,-45,-36,-24,-12,0,12,24,36,45,53,59,63,64,63,59,53,45,36,24,12};
signed int8 local2_real[128]={64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59};
signed int8 local2_imag[128]={0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24,0,-24,-45,-59,-64,-59,-45,-24,0,24,45,59,64,59,45,24};

signed int16 Multi_1coscos[128];
signed int16 Multi_1cossin[128];
signed int16 Multi_2coscos[128];
signed int16 Multi_2cossin[128];

signed int32 Filter_Multi_1coscos[96];
signed int32 Filter_Multi_1cossin[96];
signed int32 Filter_Multi_2coscos[96];
signed int32 Filter_Multi_2cossin[96];

signed int32 a;//1kreal
signed int32 b;//1kimag
signed int32 cc;//2kreal
signed int32 d;//2kimag

float aaa;
float bbb;
float ccc;
float ddd;

int Look_Up_Table_Index=0;

int i;

/***************RDA_interrupt***************/
#INT_RDA
void rda_isr(void) 
{ 
   pause=1;
   c[0]=0;//reset c
   in=0;
   do
   {
      c[in]=getc();
      putc(c[in]);
      if(c[in]==127)//backspace check
      {
         in=in-2;
      }
      in=in+1;
   }
   while((in<31)&&(c[in-1]!=13));
   c[in-1]=0;
   putc(13);//enter
   putc(10);//back to first column

   //ERROR JUDGEMENT//
   if(STRICMP(c,collectdata)!=0)
   {
      puts("ERROR");
   }
}

/***************Timer2_interrupt***************/
#int_timer2
void Timer2_Service_Routine(void)
{
   Port.cs = 0b0;//SPI Chip select signal low
   spi_xfer((CosTable[Look_Up_Table_Index])>>8); //High byte(+4096(2^12) for SHDN=1)
   spi_xfer((CosTable[Look_Up_Table_Index])&0x00FF);// Low byte
   Port.cs = 0b1;//SPI Chip select signal high
   Look_Up_Table_Index=++Look_Up_Table_Index % 32;//if already count to 32, then reset to 0
   //read_adc();
}

/***************ADC_interrupt***************/
#INT_AD
void adc_isr(void)
{  
   if(count<128)
   {
      adctable[count] = read_adc(ADC_READ_ONLY); 
      count++;
   }
}

/***************main_function***************/
void main() 
{ 
   //Port Setting//
   int BWPU;//weak pull up PIN_B
   #byte BWPU = 0x0F18;
   BWPU = 0b11111111;
      //A//
   PortDirection.PWM=0b0;
   PortDirection.ADC=0b1;
      //B//
      //C//
   PortDirection.ts=0b0;
   PortDirection.rc=0b1;
   PortDirection.cs=0b0;
   PortDirection.SDO=0b0;
   PortDirection.SCK=0b0;

   //RDA//
   enable_interrupts(INT_RDA); 
   //TIMER2//
   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_2,249,1);
   enable_interrupts(INT_TIMER2);// Timer 2 interrupt enable
   //PWM//
   setup_ccp2(CCP_PWM|CCP_USE_TIMER1_AND_TIMER2); 
   setup_pwm4(PWM_ENABLED|PWM_ACTIVE_LOW|PWM_TIMER2);
   set_pwm4_duty(64);//active low for 1us
   //ADC//
   setup_adc_ports(sAN7,VSS_FVR);
   setup_adc(ADC_LEGACY_MODE|ADC_CLOCK_DIV_64);
   setup_vref(VREF_ON|VREF_ADC_1v024);
   set_adc_channel(7);
   set_adc_trigger(ADC_TRIGGER_TIMER2);
   enable_interrupts(INT_AD);
   //GLOBAL//
   enable_interrupts(GLOBAL); 
   
   for(i=0;i<32;i++)
   {
   CosTable[i]=CosTable[i]+4096;
   }
   
   while(1)
   {
/**************ADC CONTROL*****************/ 
      if (STRICMP(c,collectdata)==0)
      {
         puts("OK");
         pause=0;
         count=0;
         while(pause==0)
         {
            if(count==128)
            {  
               long ii;
               for(ii=0;ii<128;ii++)
               {
               Multi_1coscos[ii] = local1_real[ii]*adctable[ii];
               Multi_1cossin[ii] = local1_imag[ii]*adctable[ii];
               Multi_2coscos[ii] = local2_real[ii]*adctable[ii];
               Multi_2cossin[ii] = local2_imag[ii]*adctable[ii];
               }
               for(ii=0;ii<96;ii++)
               {
               //Filter_Multi_1coscos[ii]= (Multi_1coscos[ii]+Multi_1coscos[ii+1]+Multi_1coscos[ii+2]+Multi_1coscos[ii+3]+Multi_1coscos[ii+4]+Multi_1coscos[ii+5]+Multi_1coscos[ii+6]+Multi_1coscos[ii+7]+Multi_1coscos[ii+8]+Multi_1coscos[ii+9]+Multi_1coscos[ii+10]+Multi_1coscos[ii+11]+Multi_1coscos[ii+12]+Multi_1coscos[ii+13]+Multi_1coscos[ii+14]+Multi_1coscos[ii+15]+Multi_1coscos[ii+16]+Multi_1coscos[ii+17]+Multi_1coscos[ii+18]+Multi_1coscos[ii+19]+Multi_1coscos[ii+20]+Multi_1coscos[ii+21]+Multi_1coscos[ii+22]+Multi_1coscos[ii+23]+Multi_1coscos[ii+24]+Multi_1coscos[ii+25]+Multi_1coscos[ii+26]+Multi_1coscos[ii+27]+Multi_1coscos[ii+28]+Multi_1coscos[ii+29]+Multi_1coscos[ii+30]+Multi_1coscos[ii+31]);
               //Filter_Multi_1cossin[ii]= (Multi_1cossin[ii]+Multi_1cossin[ii+1]+Multi_1cossin[ii+2]+Multi_1cossin[ii+3]+Multi_1cossin[ii+4]+Multi_1cossin[ii+5]+Multi_1cossin[ii+6]+Multi_1cossin[ii+7]+Multi_1cossin[ii+8]+Multi_1cossin[ii+9]+Multi_1cossin[ii+10]+Multi_1cossin[ii+11]+Multi_1cossin[ii+12]+Multi_1cossin[ii+13]+Multi_1cossin[ii+14]+Multi_1cossin[ii+15]+Multi_1cossin[ii+16]+Multi_1cossin[ii+17]+Multi_1cossin[ii+18]+Multi_1cossin[ii+19]+Multi_1cossin[ii+20]+Multi_1cossin[ii+21]+Multi_1cossin[ii+22]+Multi_1cossin[ii+23]+Multi_1cossin[ii+24]+Multi_1cossin[ii+25]+Multi_1cossin[ii+26]+Multi_1cossin[ii+27]+Multi_1cossin[ii+28]+Multi_1cossin[ii+29]+Multi_1cossin[ii+30]+Multi_1cossin[ii+31]);
               //Filter_Multi_2coscos[ii]= (Multi_2coscos[ii]+Multi_2coscos[ii+1]+Multi_2coscos[ii+2]+Multi_2coscos[ii+3]+Multi_2coscos[ii+4]+Multi_2coscos[ii+5]+Multi_2coscos[ii+6]+Multi_2coscos[ii+7]+Multi_2coscos[ii+8]+Multi_2coscos[ii+9]+Multi_2coscos[ii+10]+Multi_2coscos[ii+11]+Multi_2coscos[ii+12]+Multi_2coscos[ii+13]+Multi_2coscos[ii+14]+Multi_2coscos[ii+15]+Multi_2coscos[ii+16]+Multi_2coscos[ii+17]+Multi_2coscos[ii+18]+Multi_2coscos[ii+19]+Multi_2coscos[ii+20]+Multi_2coscos[ii+21]+Multi_2coscos[ii+22]+Multi_2coscos[ii+23]+Multi_2coscos[ii+24]+Multi_2coscos[ii+25]+Multi_2coscos[ii+26]+Multi_2coscos[ii+27]+Multi_2coscos[ii+28]+Multi_2coscos[ii+29]+Multi_2coscos[ii+30]+Multi_2coscos[ii+31]);
               //Filter_Multi_2cossin[ii]= (Multi_2cossin[ii]+Multi_2cossin[ii+1]+Multi_2cossin[ii+2]+Multi_2cossin[ii+3]+Multi_2cossin[ii+4]+Multi_2cossin[ii+5]+Multi_2cossin[ii+6]+Multi_2cossin[ii+7]+Multi_2cossin[ii+8]+Multi_2cossin[ii+9]+Multi_2cossin[ii+10]+Multi_2cossin[ii+11]+Multi_2cossin[ii+12]+Multi_2cossin[ii+13]+Multi_2cossin[ii+14]+Multi_2cossin[ii+15]+Multi_2cossin[ii+16]+Multi_2cossin[ii+17]+Multi_2cossin[ii+18]+Multi_2cossin[ii+19]+Multi_2cossin[ii+20]+Multi_2cossin[ii+21]+Multi_2cossin[ii+22]+Multi_2cossin[ii+23]+Multi_2cossin[ii+24]+Multi_2cossin[ii+25]+Multi_2cossin[ii+26]+Multi_2cossin[ii+27]+Multi_2cossin[ii+28]+Multi_2cossin[ii+29]+Multi_2cossin[ii+30]+Multi_2cossin[ii+31]);
               Filter_Multi_1coscos[ii]= ((signed int32)Multi_1coscos[ii]+(signed int32)Multi_1coscos[ii+1]+(signed int32)Multi_1coscos[ii+2]+(signed int32)Multi_1coscos[ii+3]+(signed int32)Multi_1coscos[ii+4]+(signed int32)Multi_1coscos[ii+5]+(signed int32)Multi_1coscos[ii+6]+(signed int32)Multi_1coscos[ii+7]+(signed int32)Multi_1coscos[ii+8]+(signed int32)Multi_1coscos[ii+9]+(signed int32)Multi_1coscos[ii+10]+(signed int32)Multi_1coscos[ii+11]+(signed int32)Multi_1coscos[ii+12]+(signed int32)Multi_1coscos[ii+13]+(signed int32)Multi_1coscos[ii+14]+(signed int32)Multi_1coscos[ii+15]+(signed int32)Multi_1coscos[ii+16]+(signed int32)Multi_1coscos[ii+17]+(signed int32)Multi_1coscos[ii+18]+(signed int32)Multi_1coscos[ii+19]+(signed int32)Multi_1coscos[ii+20]+(signed int32)Multi_1coscos[ii+21]+(signed int32)Multi_1coscos[ii+22]+(signed int32)Multi_1coscos[ii+23]+(signed int32)Multi_1coscos[ii+24]+(signed int32)Multi_1coscos[ii+25]+(signed int32)Multi_1coscos[ii+26]+(signed int32)Multi_1coscos[ii+27]+(signed int32)Multi_1coscos[ii+28]+(signed int32)Multi_1coscos[ii+29]+(signed int32)Multi_1coscos[ii+30]+(signed int32)Multi_1coscos[ii+31])/96;
               Filter_Multi_1cossin[ii]= ((signed int32)Multi_1cossin[ii]+(signed int32)Multi_1cossin[ii+1]+(signed int32)Multi_1cossin[ii+2]+(signed int32)Multi_1cossin[ii+3]+(signed int32)Multi_1cossin[ii+4]+(signed int32)Multi_1cossin[ii+5]+(signed int32)Multi_1cossin[ii+6]+(signed int32)Multi_1cossin[ii+7]+(signed int32)Multi_1cossin[ii+8]+(signed int32)Multi_1cossin[ii+9]+(signed int32)Multi_1cossin[ii+10]+(signed int32)Multi_1cossin[ii+11]+(signed int32)Multi_1cossin[ii+12]+(signed int32)Multi_1cossin[ii+13]+(signed int32)Multi_1cossin[ii+14]+(signed int32)Multi_1cossin[ii+15]+(signed int32)Multi_1cossin[ii+16]+(signed int32)Multi_1cossin[ii+17]+(signed int32)Multi_1cossin[ii+18]+(signed int32)Multi_1cossin[ii+19]+(signed int32)Multi_1cossin[ii+20]+(signed int32)Multi_1cossin[ii+21]+(signed int32)Multi_1cossin[ii+22]+(signed int32)Multi_1cossin[ii+23]+(signed int32)Multi_1cossin[ii+24]+(signed int32)Multi_1cossin[ii+25]+(signed int32)Multi_1cossin[ii+26]+(signed int32)Multi_1cossin[ii+27]+(signed int32)Multi_1cossin[ii+28]+(signed int32)Multi_1cossin[ii+29]+(signed int32)Multi_1cossin[ii+30]+(signed int32)Multi_1cossin[ii+31])/96;
               Filter_Multi_2coscos[ii]= ((signed int32)Multi_2coscos[ii]+(signed int32)Multi_2coscos[ii+1]+(signed int32)Multi_2coscos[ii+2]+(signed int32)Multi_2coscos[ii+3]+(signed int32)Multi_2coscos[ii+4]+(signed int32)Multi_2coscos[ii+5]+(signed int32)Multi_2coscos[ii+6]+(signed int32)Multi_2coscos[ii+7]+(signed int32)Multi_2coscos[ii+8]+(signed int32)Multi_2coscos[ii+9]+(signed int32)Multi_2coscos[ii+10]+(signed int32)Multi_2coscos[ii+11]+(signed int32)Multi_2coscos[ii+12]+(signed int32)Multi_2coscos[ii+13]+(signed int32)Multi_2coscos[ii+14]+(signed int32)Multi_2coscos[ii+15]+(signed int32)Multi_2coscos[ii+16]+(signed int32)Multi_2coscos[ii+17]+(signed int32)Multi_2coscos[ii+18]+(signed int32)Multi_2coscos[ii+19]+(signed int32)Multi_2coscos[ii+20]+(signed int32)Multi_2coscos[ii+21]+(signed int32)Multi_2coscos[ii+22]+(signed int32)Multi_2coscos[ii+23]+(signed int32)Multi_2coscos[ii+24]+(signed int32)Multi_2coscos[ii+25]+(signed int32)Multi_2coscos[ii+26]+(signed int32)Multi_2coscos[ii+27]+(signed int32)Multi_2coscos[ii+28]+(signed int32)Multi_2coscos[ii+29]+(signed int32)Multi_2coscos[ii+30]+(signed int32)Multi_2coscos[ii+31])/96;
               Filter_Multi_2cossin[ii]= ((signed int32)Multi_2cossin[ii]+(signed int32)Multi_2cossin[ii+1]+(signed int32)Multi_2cossin[ii+2]+(signed int32)Multi_2cossin[ii+3]+(signed int32)Multi_2cossin[ii+4]+(signed int32)Multi_2cossin[ii+5]+(signed int32)Multi_2cossin[ii+6]+(signed int32)Multi_2cossin[ii+7]+(signed int32)Multi_2cossin[ii+8]+(signed int32)Multi_2cossin[ii+9]+(signed int32)Multi_2cossin[ii+10]+(signed int32)Multi_2cossin[ii+11]+(signed int32)Multi_2cossin[ii+12]+(signed int32)Multi_2cossin[ii+13]+(signed int32)Multi_2cossin[ii+14]+(signed int32)Multi_2cossin[ii+15]+(signed int32)Multi_2cossin[ii+16]+(signed int32)Multi_2cossin[ii+17]+(signed int32)Multi_2cossin[ii+18]+(signed int32)Multi_2cossin[ii+19]+(signed int32)Multi_2cossin[ii+20]+(signed int32)Multi_2cossin[ii+21]+(signed int32)Multi_2cossin[ii+22]+(signed int32)Multi_2cossin[ii+23]+(signed int32)Multi_2cossin[ii+24]+(signed int32)Multi_2cossin[ii+25]+(signed int32)Multi_2cossin[ii+26]+(signed int32)Multi_2cossin[ii+27]+(signed int32)Multi_2cossin[ii+28]+(signed int32)Multi_2cossin[ii+29]+(signed int32)Multi_2cossin[ii+30]+(signed int32)Multi_2cossin[ii+31])/96;
               }
               a=0;
               b=0;
               cc=0;
               d=0;
               for(ii=0;ii<96;ii++)
               {
               a=a+Filter_Multi_1coscos[ii];
               b=b+Filter_Multi_1cossin[ii];
               cc=cc+Filter_Multi_2coscos[ii];
               d=d+Filter_Multi_2cossin[ii];
               }
               printf("[");
               for(ii=0;ii<128;ii++)
               {
                  if(ii<128)
                  {
                     printf("%ld ",adctable[ii]);
                  }
               }
               printf("];");
               putc(13);
               putc(10);
               /*
               printf("[");
               for(ii=0;ii<96;ii++)
               {
                  if(ii<96)
                  {
                     printf("%ld ",Filter_Multi_1coscos[ii]);
                  }
               }
               printf("];");
               putc(13);
               putc(10);
               */
               aaa=(float)a/131072;
               bbb=(float)b/131072;
               ccc=(float)cc/131072;
               ddd=(float)d/131072;
               printf("1k_Real:%f,   1k_Imag:%f,   2k_Real:%f,   2k_Imag:%f",aaa,bbb,ccc,ddd);
               putc(13);
               putc(10);
               pause=1;
            }    
        }
      c[0]=0;//reset c
      }
   }
}
