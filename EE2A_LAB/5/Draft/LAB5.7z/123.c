#include <18F27K40.h>
#device adc=8
#include<stdlib.h>
#use delay(internal=64MHZ,clock_out)
#pin_select U1TX=PIN_B0
#pin_select U1RX=PIN_B1
#use rs232(UART1,baud = 9600,BITS= 8,PARITY=N)
#pin_select PWM4=PIN_C0
#use spi(MASTER,DO=PIN_A2,MODE=0,CLK=PIN_A3,BITS=8)
#include <string.h>

   
int16 sine12hz[32]={2048,2721,3319,3773,4039,4095,3950,3638,3214,2745,2300,1940,1706,1618,1669,1829,2047,2266,2426,2477,2389,2155,1795,1350,881,457,145,0,56,322,776,1374};

unsigned int8 h1[32]={127,125,117,106,90,71,49,25,0,-25,-49,-71,-90,-106,-117,-125,-127,-125,-117,-106,-90,-71,-49,-25,0,25,49,71,90,106,117,125};
unsigned int8 h11[32]={0,-25,-49,-71,-90,-106,-117,-125,-127,-125,-117,-106,-90,-71,-49,-25,0,25,49,71,90,106,117,125,127,125,117,106,90,71,49,25};
unsigned int8 h2[32]={127,117,90,49,0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117,127,117,90,49,0,-49,-90,-117,-127,-117,-90,-49,0,49};
unsigned int8 h21[32]={0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117,127,117,90,49,0,-49,-90,-117,-127,-117,-90,-49,0,49,90,117,127,117,90,49};
//////////////////////
//////////////////////

int ATri;          //control all PinA as output or input
int AData;         //generate high or low output signal through this varible
int CTri;          //control all PinC as output
int CData;         //generate high or low output signal through this varible


typedef struct
{
  int analog:1;
  int D1:1;
  int D0:1;
  int SCK:1;
  int SC:1;
  int pad:3;
}StructA;
StructA* pstPinA;

char tem[5];
int SerialCmdWaitFlag=FALSE;
int Serial_buffer[128];

#int_RDA
void serial_isr(void)
{
  tem[0]=getc();
  putc(tem[0]);     
  if(tem[0]==0xa||tem[0] == 0xd)
  {
    SerialCmdWaitFlag=TRUE;
  }
  
  if(tem[0]==127)
  {
  
      if(strlen(Serial_buffer)>0)
      {
         Serial_buffer[strlen(Serial_buffer)-1]=0;
      }
  }
  else if(tem[0] != 0xa && tem[0] != 0xd)
    strcat(Serial_buffer, tem);
  disable_interrupts(int_rda);
}

int8 counter=0;
int16 counter1=0;
int isCollecting=0;
int isCollectComplete=0;
Unsigned int8 buffer[128];
signed int16 H11out[128];
signed int16 H12out[128];
signed int16 H21out[128];
signed int16 H22out[128];
signed int32 sum11=0;
signed int32 sum12=0;
signed int32 sum21=0;
signed int32 sum22=0;
int SerialCmdResult=0;
    int i=0;
#int_timer2
void Timer2_Service_Route(void)
{
    counter++;
    pstPinA->SC=0b0;
    spi_xfer(sine12hz[counter%32]>>8);
    spi_xfer(sine12hz[counter%32]&0x00ff);
    pstPinA->SC=0b1;
}
#int_AD
void AD_Service_Route(void)
{
  if(isCollecting==1)//collect data
  {
    
    buffer[counter1]=read_adc(ADC_READ_ONLY);
    counter1++;
    if(counter1==128)
    {
      isCollectComplete=1;
      isCollecting=0;
      counter1=0;
    }
  }
}

register _PRODH int8 Product_High_Byte;
register _PRODL int8 Product_Low_Byte;
signed int16 multify(signed int8 a,signed int8 b)
{
   return (signed int16)a*(signed int16)b;

}
void main()
{
 
   // MULT macro 
   // Performs 8x8 hardware multiply of x and y and stores the 16-bit 
   // result in xy 
   

  #byte ATri = 0x0F88;
  #byte AData = 0x0F8D;
  #byte CTri = 0x0F8A; 
  #byte CData = 0x0F8F;

  pstPinA=&ATri;
  pstPinA->analog=0b1;
  pstPinA->D1=1;
  pstPinA->D0=0;
  pstPinA->SCK=0;
  PstPinA->SC=0;
  pstPinA=&AData;
   
  CTri = 0b00000000;
  CData = 0b00000000;
   
  enable_interrupts(int_rda); 
  //setup_oscillator(OSC_HFINTRC_64MHZ);                 // Set internal oscillator to 8MHz
   

 // setup_spi(SPI_MASTER|SPI_CLK_DIV_4 );
  setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_2,249,1);
  enable_interrupts(INT_TIMER2);
  
  setup_ccp2(CCP_PWM|CCP_USE_TIMER1_AND_TIMER2); 
  setup_pwm4(PWM_ENABLED|PWM_ACTIVE_LOW|PWM_TIMER2);
  set_pwm4_duty(64);  


  setup_adc_ports(sAN0,VSS_FVR);
  setup_adc(ADC_LEGACY_MODE|ADC_CLOCK_DIV_64);
  setup_vref(VREF_ON|VREF_ADC_4v096);
  set_adc_channel(0);
  set_adc_trigger(ADC_TRIGGER_TIMER2);
  enable_interrupts(INT_AD);
  enable_interrupts(global); 
  Serial_buffer[0]=0;
  memset(tem,0,5);
   

  for(i=0;i<32;i++)
  {
   sine12hz[i]=sine12hz[i]+4096;
  }
  while (true)
  {
    enable_interrupts(int_rda); 
    if (SerialCmdWaitFlag!=TRUE)
    {
      continue;
    }
    SerialCmdWaitFlag=FALSE;
    char temCollect[20]="aa";
    
  
  
    if (strncmp(Serial_buffer, temCollect, 2) == 0)
    {
        isCollecting=1;
        while(isCollecting==1)
        {
          delay_ms(100);
          
        }
        sum11=0;
        sum12=0;
        sum21=0;
        sum22=0;
        for(int8 i=0;i<128;i++)
        {
          buffer[i]=buffer[i]-(unsigned int16)128;
          
          /*
          H11out[i]=buffer[i]*(signed int16)h1[i%32];
          H12out[i]=buffer[i]*(signed int16)h11[i%32];
          H21out[i]=buffer[i]*(signed int16)h2[i%32];
          H22out[i]=buffer[i]*(signed int16)h21[i%32];
          */
          H11out[i]=multify(buffer[i],h1[i%32]);
          H12out[i]=multify(buffer[i],h11[i%32]);
          H21out[i]=multify(buffer[i],h2[i%32]);
          H22out[i]=multify(buffer[i],h21[i%32]);

          sum11+=H11out[i];
          sum12+=H12out[i];
          sum21+=H21out[i];
          sum22+=H22out[i];
          
          
        } 
        putc(13);
            putc(10);   
            printf("buffer:");
        for(int i=0;i<128;i++)
        {
        printf("%d,",buffer[i]);
        }
         sum11=sum11/512;
         sum12=sum12/512;
         sum21=sum21/512;
         sum22=sum22/512;
         {
           putc(13);
               putc(10);   
           printf("sum11:%ld,",sum11);
           putc(13);
               putc(10);   
           printf("sum12:%ld,",sum12);
           putc(13);
               putc(10);   
           putc(13);
               putc(10);   
           printf("sum21:%ld,",sum21);
           putc(13);
               putc(10);   
           printf("sum22:%ld,",sum22);
           putc(13);
               putc(10);   
          
         }
        
        
        isCollecting=0;
        SerialCmdResult=1;
    }
    if(SerialCmdResult==1)
    {
      putc(13);     
      putc(10);   
      printf("OK");
    }
    else if(Serial_buffer[0]!=0)
    {
      putc(13);     
      putc(10);   
      printf("bad command");
    }
     
    putc(13);     
    putc(10);   
    SerialCmdResult=0;
    Serial_buffer[0]=0;
  }
}
/*
#include <18F27K40.h>
#device adc=10
#fuses NOWDT,NOPUT,NOPROTECT,BROWNOUT,NOMCLR,LVP,NOCPD
#use delay(clock=8000000)
#pin_select U1TX=PIN_B0
#pin_select U1RX=PIN_B1
#use rs232(UART1,baud = 9600,BITS= 8,PARITY=N)
char a='1';


#INT_RDA
void serial_isr(void) {
  a='2';
  disable_interrupts(INT_RDA);
}


void main() {
   a='1';
   setup_oscillator(OSC_HFINTRC_8MHZ);

   enable_interrupts(INT_RDA);
   enable_interrupts(global);

   printf("\r\n\Running...\r\n");

               // The program will delay for 10 seconds and then display
               // any data that came in during the 10 second delay

   do {
   
      delay_ms(100);
      putc(a);
      enable_interrupts(INT_RDA);
      
  
      delay_ms(1000);
      printf("\r\nBuffered data => ");
      while(bkbhit)
        putc( bgetc() );
   } while (TRUE);
}

*/






