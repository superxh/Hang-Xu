#include<18F27K40.h>
#use delay(internal=32Mhz,clock_out)
#use spi(MASTER,DO=PIN_C3,MODE=0,CLK=PIN_C5,BITS=8)
#pin_select PWM4=PIN_A0
//#pin_select SDO2=PIN_C3
//#pin_select SDO1=PIN_C4
//#pin_select SCK2=PIN_C5
//#pin_select SCK1=PIN_C7

int16 SineTab1e[3][32]={
{2048   ,2447   ,2831   ,3185   ,3495   ,3750   ,3939   ,4056   ,4095   ,4056   ,3939   ,3750   ,3495   ,3185   ,2831   ,2447   ,2048   ,1648   ,1264   ,910   ,600   ,345   ,156   ,39   ,0   ,39   ,156   ,345   ,600   ,910   ,1264   ,1648   },
{2048   ,2831   ,3495   ,3939   ,4095   ,3939   ,3495   ,2831   ,2048   ,1264   ,600   ,156   ,0   ,156   ,600   ,1264   ,2048   ,2831   ,3495   ,3939   ,4095   ,3939   ,3495   ,2831   ,2048   ,1264   ,600   ,156   ,0   ,156   ,600   ,1264   },
{2048   ,2639   ,3163   ,3562   ,3795   ,3845   ,3717   ,3443   ,3071   ,2660   ,2269   ,1953   ,1748   ,1670   ,1715   ,1855   ,2048   ,2240   ,2380   ,2425   ,2347   ,2142   ,1826   ,1435   ,1024   ,652   ,378   ,250   ,300   ,533   ,932   ,1456   }
};
int Look_Up_Table_Index=0;
int Select_Table;

struct IO_Port_Definition
{
   int1 LDAC;//PIN_C0
   int1 debug;//PIN_C1
   int1 cs; //PIN_C2
   int1 SDO2;//PIN_C3
   int1 SDO1;//PIN_C4
   int1 SCK2;//PIN_C5
   int1 unused;//PIN_C6
   int1 SCK1;//PIN_C7
};
struct IO_Port_Definition Port;
struct IO_Port_Definition PortDirection;
#byte Port = 0xF8F
#byte PortDirection = 0xF8A

#int_timer2
void Timer2_Service_Routine(void)
{
   if (input(PIN_B0)==0 && input(PIN_B1)==0)
   {
      Select_Table=0;
   }
   if (input(PIN_B0)==0 && input(PIN_B1)==1)
   {
      Select_Table=1;
   }
   if (input(PIN_B0)==1 && input(PIN_B1)==0)
   {
      Select_Table=2;
   }  
   Port.debug = 0b1;
   Port.cs = 0b0;
   //spi_write2(4095);
   //spi_write2(00);
   spi_xfer((4096+SineTab1e[Select_Table][Look_Up_Table_Index])>>8);
   spi_xfer((4096+SineTab1e[Select_Table][Look_Up_Table_Index])&0x00FF);
   Port.cs = 0b1;
   Look_Up_Table_Index=++Look_Up_Table_Index % 32;
   Port.debug = 0b0;
  }  

void main()
{
   PortDirection.debug = 0b0;
   PortDirection.cs = 0b0;

   //setup_spi(SPI_MASTER|SPI_L_TO_H); 
   //setup_spi2(SPI_MASTER|SPI_L_TO_H); 

   setup_timer_2(T2_CLK_INTERNAL|T2_DIV_BY_1,249,1);
   setup_ccp2(CCP_PWM|CCP_USE_TIMER1_AND_TIMER2); 
   setup_pwm4(PWM_ENABLED|PWM_ACTIVE_LOW|PWM_TIMER2);
   set_pwm4_duty(32);

   enable_interrupts(INT_TIMER2);
   enable_interrupts(GLOBAL);
   while(1)
   {
   }

}
